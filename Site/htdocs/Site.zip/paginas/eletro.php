<row>
<div class="panel panel-default">
	<div class="panel-heading">
		<center>
               	<h3>Outros</h3>
    	</center>
    </div>
    <div class="panel-body">
    	<div class="panel panel-default">
    		<div class="panel-body">
    			<div class="panel panel-default col-sm-3  col-sm-offset-1 ">
                    <div class="panel-body preto">
                         <form action="#" method="POST" id="fquarto2">
                         	<input type="hidden" name="foutros" value="1">
                            <center>
                              <h4><img src="imgs/portas.png" width="20px" height="20px"/> Portao garagem</h4>
                              <hr>
                            </center>                           	
                           </form>
                        </div>
                    </div>
    			<div class="panel panel-default col-sm-3  col-sm-offset-2 ">
                    <div class="panel-body preto">
                         <form action="#" method="POST" id="fquarto2">
                         	<input type="hidden" name="foutros" value="1">
                            <center>
                              <h4><img src="imgs/ventilador.png" width="20px" height="20px"/> Ventilador cozinha</h4>
                              <hr>

                            </center>                           	
                        </form>
                    </div>
               </div>
    		</div>
    	</div>
    </div>
</div>
</row>