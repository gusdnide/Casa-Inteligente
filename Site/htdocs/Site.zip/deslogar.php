<?php
	setcookie("logado");
	header(("Location: index.php"));
?>